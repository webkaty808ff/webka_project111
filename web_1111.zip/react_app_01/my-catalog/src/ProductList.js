import React from 'react';

const products = [
  // Здесь добавьте объекты товаров, например:
  { id: 1, name: 'Стул', description: 'Удобный деревянный стул' },
  // Добавьте столько объектов, сколько нужно
];

const ProductList = () => {
  return (
    <div>
      {products.map(product => (
        <div key={product.id}>
          <h3>{product.name}</h3>
          <p>{product.description}</p>
        </div>
      ))}
    </div>
  );
};

export default ProductList;
