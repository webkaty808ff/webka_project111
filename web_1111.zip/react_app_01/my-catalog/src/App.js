import './App.css';

function App() {
  return (
    <div>
    <div id="product-catalog"></div>
    <div id="pdfViewer"></div>
    <header>
        <nav className="navbar navbar-expand-lg navbar-dark bg-dark">
            <a className="navbar-brand" href="#">wooden.mebel</a>
            <div className="collapse navbar-collapse" id="navbarNav">
              <ul className="navbar-nav">
                <li className="nav-item active">
                  <a className="nav-link" href="#">Главная</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">Про нас</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">Наши работы</a>
                </li>
                <li className="nav-item">
                  <a className="nav-link" href="#">Ценники</a>
                </li>
              </ul>
            </div>
          </nav>
                   
    </header>
    <section className="welcome" id="welcome">
        <div className="container">
            <div className="welcome-inner">
                <h1>wooden</h1>
                <h1>Мы создаем самые качественные, комфортные <br /> и доступные мебели</ h1>
                <button id="welcome-button">Наши Товары</button>
                <div id="product-catalog"></div>
            </div>
        </div>
    </section> 
    <section className="about" id="about">
        <div className="container">
            <div className="about-inner">
                <h1>Стулья нашей мечты</h1>
                <p> (Самые популярные запросы покупателей.)</p>
                <div className="about-list">
                    <div className="about-item">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRz-BiATEEHhMEgrXxWwobxLJRV9LRnnPTs6L83yOp-KPoJNcLfGGDvTL0j-KLoOn41STc&usqp=CAU"
                            alt=""/>
                        <span className="about-text">
                            <h2>Кресло "Реджина" (покраска под дерево)</h2>
                            <p>Хорошое, удобное и шикарное кресло.</p>
                        </span>
                    </div>
                    <div className="about-item">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTlAwJs2BcWzEtZJLq2s-_emLwY-thLCSY71Q&usqp=CAU"
                            alt=""/>
                        <span className="about-text">
                            <h2>Стул "Лион №2" (покраска под дерево)</h2>
                            <p>Самое популярное и дешевое , Хорошй выбор для семейных посиделок</p>
                        </span>
                    </div>
                    <div className="about-item">
                        <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT4615_f3s-tzqrQ1uog32KUzy2AtPPF9_DDBSXF2_R5C8Ch4Lb8CoRWGq5FBF4wQl6xjU&usqp=CAU"
                            alt=""/>
                        <span className="about-text">
                            <h2>Кресло "Мажор"</h2>
                            <p>Для настоящих мажоров и боссов.</p>
                        </span>
                    </div>
                    <div className="about-item">
                        <img src="https://cdn.fugamobilya.com.tr/product_files/ODc=/images/x-kitaplik-3.jpg"
                            alt=""/>
                        <span className="about-text">
                            <h2>Стеллаж "Рейджер"</h2>
                            <p>Для для хранения сейфов и мечты.</p>
                        </span>
                    </div>
                </div>
                <button id="about-button"> Все Услуги</button>
            </div>
        </div>
    </section>
    <section className="services" id="services">
        <div className="container">
            <div className="services-inner">
                <div className="services-info">
                    <div className="services-text">
                        <h2>Высокие качества <br /> мебели</h2>
                        <p>Выбор мебели – дело непростое, особенно трудно, среди множества конкурирующих фирм, выделить
                            те немногие, которые занимаются производством качественной мебели. И вообще, что именно
                            включает в себя понятие качественной мебели? На что следует обратить внимание при выборе и
                            на что обращает внимание наша компания при производстве? – на основании этих вопросов мы
                            постараемся дать несколько рекомендаций покупателю, чтобы он смог определить достойного
                            производителя.</p>
                        <a href="#">Подробнее о товаре</a>
                    </div>
                    <img className="services-image"
                        src="https://pinskdrev.kz/web/files/imagick_cache/w580h580t3/web/catalogfiles/catalog/offers/Lotta_brego07-salv15_18gr_6ML25M8M.jpg"
                        alt=""/>
                </div>
                <div className="services-list">
                    <div className="services-item">
                        <h3>
                            <img src="https://bfs01.getcourse.ru/public/files/208688/179/5cf5ff332f4f852d98964bb75685fc36.png?e=1623340799&s=OJVZNT9hRFfcC9KK9hE3aA"
                                alt=""/>
                        </h3>
                        <p></p>
                    </div>
                    <div className="services-item">
                        <h3>
                            <img src="https://bfs01.getcourse.ru/public/files/208688/179/5cf5ff332f4f852d98964bb75685fc36.png?e=1623340799&s=OJVZNT9hRFfcC9KK9hE3aA"
                                alt=""></img>
                        </h3>
                        <p></p>
                    </div>
                    <div className="services-item">
                        <h3>
                            <img src="https://bfs01.getcourse.ru/public/files/208688/179/5cf5ff332f4f852d98964bb75685fc36.png?e=1623340799&s=OJVZNT9hRFfcC9KK9hE3aA"
                                alt=""></img>
                        </h3>
                        <p></p>
                    </div>
                    <div className="services-item">
                        <h3>
                            <img src="https://bfs01.getcourse.ru/public/files/208688/179/5cf5ff332f4f852d98964bb75685fc36.png?e=1623340799&s=OJVZNT9hRFfcC9KK9hE3aA"
                                alt=""> </img>
                        </h3>
                        <p></p>
                    </div>
                    <div className="services-item">
                        <h3>
                            <img src="https://bfs01.getcourse.ru/public/files/208688/179/5cf5ff332f4f852d98964bb75685fc36.png?e=1623340799&s=OJVZNT9hRFfcC9KK9hE3aA"
                                alt=""> </img>
                        </h3>
                        <p></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section className="works" id="works">
        <div className="container">
            <div className="works-inner">
                <div className="works-title">
                    <h1>Наши работы, на которых <br /> мы спецализируемся </h1>
                </div>
                <div className="works-list">
                    <div className="works-item">
                        <img className="wer"
                            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQwMhXsMEzqbi2lxiSXgv79HMJA9BKL_GGoJA&usqp=CAU"
                            alt=""></img>
                        <h2> <span> 01.</span> Спальная мебель</h2>
                        <p>Стильный и оригинально оформленный спальный гарнитур замечательно впишется в интерьер любой
                            спальной комнаты, придав ей совершенно новый вид, при этом весьма гармонично сочетаясь с
                            общим дизайном.</p>
                        <a href="">Подробнее</a>
                    </div>
                    <div className="works-item">
                        <img className="wer"
                            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ620CicTQdi6ku2xoGVPCKFKrOuR16JnP_7w&usqp=CAU"
                            alt=""> </img>
                        <h2><span> 01.</span> Кухонная мебель </h2>
                        <p>Мебель для кухни (кухонная мебель) — мебель, специально предназначенная для хранения в
                            квартирах и индивидуальных домах продуктов питания, бытовой утвари и посуды для
                            приготовления пищи, столового белья, столовых приборов и столовой посуды</p>
                        <a href="">Подробнее</a>
                    </div>
                    <div className="works-item">
                        <img className="wer"
                            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ5i1DRCzlETEys2DbvT5kfrmxgywF_A4AfjA&usqp=CAU"
                            alt=""> </img>
                        <h2><span> 01.</span> Гостинная мебель</h2>
                        <p>Гостиная в квартире – это то помещение, где принимают гостей, где проходят семейные или
                            дружеские посиделки, где приятно расслабиться и посмотреть телевизор после тяжелой рабочей
                            недели.</p>
                        <a href="">Подробнее</a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section className="port" id="port">
        <div className="container">
          <div className="port-inner">
            <h1>Наши проекты</h1>
            <p>Посмотрите на наши проекты.</p>
            <div className="port-images">
              <div className="project-card">
                <img src="/img/i1.png" alt="Проект 1"> </img>
                <p>Описание проекта 1</p>
                <button>Подробнее</button>
              </div>
              <div className="project-card">
                <img src="/img/i2.png" alt="Проект 2">
                <p>Описание проекта 2</p>
                <button>Подробнее</button> </img>
              </div>
              <div className="project-card">
                <img src="/img/ш3.png" alt="Проект 1">
                <p>Описание проекта 1</p>
                <button>Подробнее</button> </img>
              </div>
            </div>
            <div className="port-button">
              <button>Все проекты</button>
            </div>
          </div>
        </div>
      </section>
      
       <section  className="pricing-section">
        <div className="container">
          <div className="row">
            <div className="col-md-4">
              <div className="pricing-plan">
                <div className="card">
                  <img src="/img/m1.png" alt="Стулья" className="card-image"/>
                  <h4>Стулья</h4> 
                  <p>Элитные стулья мебели - роскошь, стиль, качество, комфорт.</p>
                  <p>Цена: $10000</p>
                  <a href="chair.html">Посмотреть</a>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="pricing-plan">
                <div className="card">
                  <img src="/img/m2.png" alt="Диваны" className="card-image"/>
                  <h4>Диваны</h4>
                  <p>Элитные диваны: роскошь, утонченность, изысканность, комфорт, долговечность.</p>
                  <p>Цена: $20000</p>
                  <a href="sofa.html">Посмотреть</a>
                </div>
              </div>
            </div>
            <div className="col-md-4">
              <div className="pricing-plan">
                <div className="card">
                  <img src="/img/m3.png" alt="Другие гарнитуры" className="card-image"/>
                  <h4>Другие гарнитуры</h4> 
                  <p>Элитные гарнитуры мебели: роскошь, элегантность, дизайн, комфорт, индивидуальность.</p>
                  <p>Цена: $15000</p>
                  <a href="furniture.html">Посмотреть</a>
                </div>
              </div>
            </div>
            </div>
          </div>
        </section>   
          
      
        <section className="video" id="video">
            <div className="container">
              <div className="video-inner">
                <h1>Видео о нашей работе</h1>
                <p>Просто посмотрите, как мы работаем.</p>
                <div className="video-box">
                  <iframe width="1000" height="500" src="https://www.youtube.com/embed/ijfMcMTwGd4" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
              </div>
            </div>
          </section>
          
          <section className="footer">
              <div className="container">
                <div className="footer-inner">
                  <div className="footer-content">
                    <div className="footer-links">
                      <div className="footer-title">
                        Контактная информация
                      </div>
                      <ul className="footer-list">
                        <li className="footer-item">
                          <a href="#">Главная</a>
                        </li>
                        <li className="footer-item">
                          <a href="#">Наши работы</a>
                        </li>
                        <li className="footer-item">
                          <a href="#">Наши услуги</a>
                        </li>
                        <li className="footer-item">
                          <a href="#">Контакты</a>
                        </li>
                      </ul>
                    </div>
                  </div>
                </div>
            </div> 
          </section>
  );
}

export default App;
