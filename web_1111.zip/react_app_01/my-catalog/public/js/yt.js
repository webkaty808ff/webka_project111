<script>
  // Функция для создания и настройки плеера YouTube
  function onYouTubeIframeAPIReady() {
    var videoId = 'https://youtu.be/ijfMcMTwGd4'; // Замените на ID вашего видео с YouTube
    var player = new YT.Player('player', {
      height: '360', // Высота плеера
      width: '640', // Ширина плеера
      videoId: videoId, // ID видео
      playerVars: {
        'autoplay': 0, // 1 для автовоспроизведения, 0 для отключения автовоспроизведения
        'controls': 1, // 0 для скрытия элементов управления
        'rel': 0, // 0 для отключения рекомендаций после воспроизведения
        'showinfo': 0 // 0 для скрытия информации о видео
      },
      events: {
        'onReady': onPlayerReady
      }
    });
  }

  // Функция, которая вызывается, когда плеер YouTube готов
  function onPlayerReady(event) {
    // Вы можете добавить дополнительные действия здесь, если необходимо
  }
</script>
