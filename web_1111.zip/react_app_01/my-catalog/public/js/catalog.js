const ProductCatalog = () => {
    // Массив объектов товаров
    const products = [
      { id: 1, name: 'Стулья', description: 'Стулья для домашнего использования RR' },
      { id: 2, name: 'Кухня', description: 'Кухня для домашнего использования RR' },
      { id: 3, name: 'Диван', description: 'Диван для домашнего использования RR' },
      { id: 4, name: 'Гарнитура', description: 'Гарнитура для домашнего использования RR' },
      // Добавьте все ваши товары здесь
    ];
  
    // Отрисовка каталога товаров
    return (
      <div>
        {products.map(product => (
          <div key={product.id}>
            <h3>{product.name}</h3>
            <p>{product.description}</p>
          </div>
        ))}
      </div>
    );
  };
  
  // Рендеринг компонента в DOM
  ReactDOM.render(<ProductCatalog />, document.getElementById('product-catalog'));
  