import React from 'react';
import ReactDOM from 'react-dom';
import MyPdfViewer from './MyPdfViewer'; // Импортируйте ваш компонент
import React, { useState } from 'react';
import { Document, Page } from 'react-pdf';

// Импортируйте PDF-файлы
import pdfFile1 from './path/to/your/first/document.pdf';
import pdfFile2 from './path/to/your/second/document.pdf';
// Импортируйте другие PDF-файлы аналогично

function MyPdfViewer() {
  const [file, setFile] = useState("");

  return (
    <div>
      <button onClick={() => setFile(pdfFile1)}>Load First PDF</button>
      <button onClick={() => setFile(pdfFile2)}>Load Second PDF</button>
      {/* Создайте больше кнопок для других PDF-файлов, используя аналогичный подход */}

      {file && (
        <Document file={file}>
          <Page pageNumber={1} />
        </Document>
      )}
    </div>
  );
}


ReactDOM.render(<MyPdfViewer />, document.getElementById('pdfViewer'));
